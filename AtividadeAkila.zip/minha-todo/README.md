# Minha Lista de Tarefas

Aplicação de lista de tarefas desenvolvida com React + Vite como atividade prática da disciplina.

## Como rodar

```bash
npm install
npm run dev
```

Acesse: `http://localhost:5173`

## O que foi feito

### JSX

JSX é uma extensão de sintaxe do JavaScript que permite escrever HTML dentro do código JS. O React transforma esse JSX em chamadas JavaScript puras. Diferente do HTML puro, no JSX usamos `className` em vez de `class`, e expressões JS ficam entre `{}`.

### Componentes

Componentes são funções que retornam JSX. Cada parte da interface pode ser um componente reutilizável. O componente principal da aplicação é o `App`.

### useState

`useState` é um hook do React que adiciona estado a um componente funcional. Ele retorna o valor atual e uma função para atualizá-lo. Toda vez que o estado muda, o componente re-renderiza automaticamente.

### Hooks

Hooks são funções especiais do React que sempre começam com `use`. Permitem usar recursos como estado (`useState`) e efeitos colaterais (`useEffect`) em componentes funcionais.

## Funcionalidades

- Adicionar tarefas com botão ou tecla Enter
- Remover tarefas individualmente
- Contador de tarefas
- Mensagem quando a lista está vazia

## Estrutura do projeto

```
minha-todo/
├── src/
│   ├── App.jsx
│   ├── App.css
│   └── main.jsx
├── index.html
├── vite.config.js
└── README.md
```

## Tecnologias

- React
- Vite
- CSS puro
