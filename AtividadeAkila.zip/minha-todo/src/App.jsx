// App.jsx
// Componente principal da aplicação de lista de tarefas
// Usa o hook useState para gerenciar o estado das tarefas e do input

import { useState } from 'react';
import './App.css';

function App() {
  // Estado para armazenar a lista de tarefas
  const [tarefas, setTarefas] = useState([]);
  // Estado para armazenar o valor atual do input
  const [input, setInput] = useState("");

  // Função para adicionar uma nova tarefa à lista
  function adicionarTarefa() {
    if (input.trim()) {
      setTarefas([...tarefas, input.trim()]);
      setInput("");
    }
  }

  // Função para remover uma tarefa pelo índice
  function removerTarefa(index) {
    const novaLista = tarefas.filter((_, i) => i !== index);
    setTarefas(novaLista);
  }

  // Permite adicionar tarefa pressionando Enter
  function handleKeyDown(e) {
    if (e.key === 'Enter') adicionarTarefa();
  }

  return (
    <div className="container">
      <h1>📝 Minha Lista de Tarefas</h1>

      <div className="input-area">
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Digite uma nova tarefa..."
        />
        <button onClick={adicionarTarefa}>Adicionar</button>
      </div>

      {tarefas.length === 0 ? (
        <p className="empty-msg">Nenhuma tarefa ainda. Adicione uma acima!</p>
      ) : (
        <ul>
          {tarefas.map((tarefa, index) => (
            <li key={index}>
              <span>{tarefa}</span>
              <button className="remove-btn" onClick={() => removerTarefa(index)}>
                ✕
              </button>
            </li>
          ))}
        </ul>
      )}

      <p className="counter">
        {tarefas.length} tarefa{tarefas.length !== 1 ? 's' : ''} na lista
      </p>
    </div>
  );
}

export default App;
